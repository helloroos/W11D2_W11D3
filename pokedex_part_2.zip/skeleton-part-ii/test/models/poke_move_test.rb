require 'test_helper'

class PokeMoveTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
